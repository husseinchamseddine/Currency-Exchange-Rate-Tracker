package com.chams.exchange;

public interface OnPageCompleteListener {
    void onPageCompleted();
}
