package com.chams.exchange;

public interface PageCompleter {
    void setOnPageCompleteListener(OnPageCompleteListener onPageCompleteListener);
}
